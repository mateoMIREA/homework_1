/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.vklad;

import java.util.Scanner;

/**
 *
 * @author М_З_А
 */
public class Vklad {

    public static void main(String[] args) {
        System.out.println("4 вариант, группа РИБО-01-21, студент Новиков М.С.");
        Scanner scan = new Scanner(System.in);
        System.out.println("Введите начальную сумму вклада");
        double s = scan.nextInt();
        System.out.println("Введите длительность вклада (в месяцах)");
        int m = scan.nextInt();
        System.out.println("Введите процент по вкладу");
        double p = scan.nextInt();
        if (!(s > 0 & m > 0 & p > 0)) {
            System.out.println("Значения введены неверно!");
            }
        double pr = p/100.0;
        double mes = s * pr;
        int x = 1;
        double od = 0;
        while(x <= m){
        od = od + mes;
        x++;
        }
        System.out.println("Месячный доход по вкладу: " + mes);
        System.out.println("Общий доход по вкладу: " + od);
    }
}
